//V2.7

players=[]
block_list=[]
entities=[]




//V2.7
if(is_server){
    var {over_world} = require("./world/generation/over_wold")
}

//World
AirDrag=.4
friction=1.1

gravity=1
max_terminal_val=18



//Funtion that Both the Server and Clint can access
function run_function(function_name,parameters){
    let new_function=typeof window != 'undefined' ? window : global

    new_function[function_name].apply(null,parameters)
}




//Save data
make_new_world=false

if(!is_server){
    if(selected_status=="offline"){

        if(selected_slot){
            // selected_world=eval("get("+JSON.stringify("slot"+selected_slot)+  ")" )
            selected_world=get("slot"+selected_slot)
            // console.log(selected_world===null)
            if((!selected_world) || selected_world === null || typeof selected_world.world=="undefined" || typeof selected_world.world[0][0].name=="undefined"){

                if((!selected_world === null) && (typeof selected_world.world=="undefined" || typeof selected_world.world[0][0].name=="undefined")){
                    alert("world Is Corrupted!")
                }
                make_new_world=true
            }
        }
    }

}
else{
    
    make_new_world=true

}

function randomize_list(list){
    let old_list=list.splice(0)

    list.splice(0,list.length)
    

    let length=old_list.length
    for(let num=0;num<length;num++){
        let i = Math.round((old_list.length-1)*Math.random())


        list.push(old_list[i])

        old_list.splice(i,1)           
    }

    return list

}


let all_mushrooms_colors=[
    "red_mushroom",
    "green_mushroom",
    "blue_mushroom"
]

let all_mushrooms_effects=[
    {"effect":"poison","knowledge":"Kills you when eaten"},
    {"effect":"regeneration","knowledge":"Heals you when eaten"},
    {"effect":"saturation","knowledge":"Has no effect when eaten."}
]

// mushrooms={}


if(!multiplayer){
    if(!make_new_world && !is_server){
        // alert("w")
        block_list=convert_names_to_blocks(selected_world.world)
    }
    else{
        world_size=[200,100]
        // seed=204
        seed=105

        // seed=parseInt(Math.random()*1000)







        
        block_list=over_world({
            "seed":seed,
            "oct":3
        })

        randomize_list(all_mushrooms_effects)
        

        
 
        // for(let num=0;num<3;num++){
        //     let i = Math.round((all_mushrooms_effects.length-1)*Math.random())

        //     mushrooms[all_mushrooms_colors[num]]=all_mushrooms_effects[i]

        //     all_mushrooms_effects.splice(i,1)           
        // }





        // console.log( "knowledge_tablet_red_"+mushrooms["red_mushroom"].effect+"_image" )

        // console.log( window["knowledge_tablet_green_"+mushrooms["green_mushroom"].effect+"_image"] )
        // console.log( window["knowledge_tablet_blue_"+mushrooms["blue_mushroom"].effect+"_image"] )



        
    }

}





function regeneration_mushroom(){
    player.add_effect("regeneration",30000)

    // for(mushroom in all_mushrooms_effects){
    for(let mushroom_index=0;mushroom_index<all_mushrooms_effects.length;mushroom_index++){
        mushroom=all_mushrooms_effects[mushroom_index]
    
    
        // if(mushrooms[mushroom].effect=="regeneration"){
        //     let knowledge_needed=player.add_knowledge({"name":mushroom,"text":mushrooms[mushroom].knowledge})
        //     // player.add_knowledge({"name":mushroom,"text":mushrooms[mushroom].knowledge})
        //     if(knowledge_needed){
        //         chat.push({
        //             "text":"Knowledge: "+get_block(mushroom).display_name+"s heal you when eaten.",
        //             "end_time":engin.time_in_loop+5000,"color":"219, 209, 7"
        //         })                        
        //     }

        // }

        if(mushroom.effect=="regeneration"){
            let knowledge_needed=player.add_knowledge({"name":all_mushrooms_colors[mushroom_index],"text":mushroom.knowledge})
           
            if(knowledge_needed){
                chat.push({
                    "text":"Knowledge: "+get_block(all_mushrooms_colors[mushroom_index]).display_name+"s heal you when eaten.",
                    "end_time":engin.time_in_loop+5000,"color":"219, 209, 7"
                })                        
            }

        }
        
    }
}

function poison_mushroom(){
    player.add_effect("poison",5000)

    for(let mushroom_index=0;mushroom_index<all_mushrooms_effects.length;mushroom_index++){
        mushroom=all_mushrooms_effects[mushroom_index]

        if(mushroom.effect=="poison"){
            let knowledge_needed=player.add_knowledge({"name":all_mushrooms_colors[mushroom_index],"text":mushroom.knowledge})
           
            if(knowledge_needed){
                chat.push({
                    "text":"Knowledge: "+get_block(all_mushrooms_colors[mushroom_index]).display_name+"s are poisonous.",
                    "end_time":engin.time_in_loop+5000,"color":"219, 209, 7"
                })                        
            }

        }
        
    }

}

function saturation_mushroom(){
    // player.add_effect("poison",5000)

    for(let mushroom_index=0;mushroom_index<all_mushrooms_effects.length;mushroom_index++){
        mushroom=all_mushrooms_effects[mushroom_index]

        if(mushroom.effect=="saturation"){
            let knowledge_needed=player.add_knowledge({"name":all_mushrooms_colors[mushroom_index],"text":mushroom.knowledge})
           
            if(knowledge_needed){
                chat.push({
                    "text":"Knowledge: "+get_block(all_mushrooms_colors[mushroom_index]).display_name+"s are safe to eat.",
                    "end_time":engin.time_in_loop+5000,"color":"219, 209, 7"
                })                        
            }

        }
        
    }
}





red_mushroom_function = window[all_mushrooms_effects[0].effect+"_mushroom"]

green_mushroom_function = window[all_mushrooms_effects[1].effect+"_mushroom"]

blue_mushroom_function = window[all_mushrooms_effects[2].effect+"_mushroom"]



knowledge_tablet_image.push(window["knowledge_tablet_red_"+all_mushrooms_effects[0].effect+"_image"])

knowledge_tablet_image.push(window["knowledge_tablet_green_"+all_mushrooms_effects[1].effect+"_image"])

knowledge_tablet_image.push(window["knowledge_tablet_blue_"+all_mushrooms_effects[2].effect+"_image"])

knowledge_tablet_image.push(knowledge_tablet_overlay_image)







if(is_server){
    module.exports={players,entities,block_list}
}