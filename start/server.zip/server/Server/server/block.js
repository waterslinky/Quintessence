//V2.7

// const { block_list } = require("./setup_world")


reseve=false
change_block=function(x,y,block_name,break_block=false){

    if(break_block && !is_server){
        let current_block=block_list[x][y].image
        for(let i=0;i<5;i++){
            
            
            // console.log(current_block)
            let color=false

            try{
                color=image_pixles(current_block)[Math.round((current_block.width-1)*Math.random()) ][Math.round((current_block.height-1)*Math.random())  ]  
            }
            catch{
                console.log("err")
            }
            
            

            if(color){
                // alert("color")
                particles.push(new par(x*block_size,y*block_size,engin.time_in_loop+700+(Math.random()*400),color ))

            }


            
        }    
    }


    if(block_list[x][y].hit_box_index!=undefined){
        let start_x=x-block_list[x][y].hit_box_index[0]
        let start_y=y+((block_list[x][y].main_hit_box_size[1]-1)-block_list[x][y].hit_box_index[1])

        let width=block_list[x][y].main_hit_box_size[0]
        let hieght=block_list[x][y].main_hit_box_size[1]



        for(let x_i=0;x_i<width;x_i++){
            for(let y_i=0;y_i>hieght*-1;y_i--){
                let x=start_x+x_i
                let y=start_y+y_i

                // console.log(block_list[x][y].hit_box_index[1]+"  "+(y_i+(hieght/2)))
                if(typeof block_list[x][y].hit_box_index!="undefined" && block_list[x][y].hit_box_index[0]==x_i && block_list[x][y].hit_box_index[1]+"  "+(y_i+(hieght/2))){
                    block_list[x][y]=get_block("air")
                }
                
            }
        }

        
        // console.log(block_list[x][y].hit_box_index)
    }


    let new_block=get_block(block_name)


    if(new_block.hit_box!=undefined){
        console.log("HITBOX")
        for(let y_index=0;y_index<new_block.hit_box[1];y_index++){
            for(let x_index=0;x_index<new_block.hit_box[0];x_index++){
                    block_list[x+x_index][y-((new_block.hit_box[1]-1)-y_index)]=get_block(block_name)
                    block_list[x+x_index][y-((new_block.hit_box[1]-1)-y_index)].hit_box_index=[x_index,y_index]
                    block_list[x+x_index][y-((new_block.hit_box[1]-1)-y_index)].main_hit_box_size=new_block.hit_box
                    // console.log([x_index,y_index])
                
            }
        }
    }
    else{
        block_list[x][y]=new_block
    }

    
 
 
    // if(!reseve && !is_server){
    //     console.log("CHANGE BLOCK")
        emit_self_data("change_block",arguments)
    // }

    
    

}





blank_area=function(x,y,width,hieght){

    // console.log([x,y,width,hieght])
    let solid_found=false
    for(let x_i=x;x_i<x+width;x_i++){
        for(let y_i=y;y_i>y-hieght;y_i--){
            // console.log("f")
            if(block_list[x_i][y_i].name!="air"){
                solid_found=true
            // console.log("solid_found")

            }
        }
    }
    // console.log("f")

    return !solid_found
}




// function convert_names_to_blocks(block_list_names){
//     let block_list=[]

//     alert("P")
//     console.log(block_list_names)
//     for(let x=0;x<block_list_names.length;x++){
//         let line=[]
//         for(let y=0;y<block_list_names[0].length;y++){
//             let block=block_list_names[x][y]

//             if(typeof block_list_names[x][y].name!="undefined"){
//                 block=block_list_names[x][y].name
//                 console.log("GRGRRGRGGRGRGR")

//                 console.log(block_list_names[x][y].data)
//             }

//             line.push(get_block(block))
//         }
//         block_list.push(line)
    
//     }

    
//     return block_list
// }

function convert_blocks_to_names(){
    let new_block_list=[]
    for(let x=0;x<block_list.length;x++){
        let line=[]
        for(let y=0;y<block_list[0].length;y++){
            line.push(block_list[x][y].name)
        }
        new_block_list.push(line)
    
    }

    
    return JSON.stringify(new_block_list)
}











function block_is(x,y,name){
    if(x<0){
        x=0
    }
    if(x>block_list.length-1){
        x=block_list.length-1
    }

    if(y<0){
        y=0
    }
    if(y>block_list.length-1){
        y=block_list.length-1
    }

    return block_list[x][y].name==name
}


function get_block(item){
    let block=""

    if(typeof item=="object"){
        block=new blocks[item.item]()
        block.type="block"  
        block.count=item.count
    }
    else{
        block=new blocks[item]()
        block.type="block"        
    }

    // if(typeof block.hit_box!="undefined"){
    //     block.type="block"        

    // }

    return block
}




function export_block_list(){

    let new_block_list=[]
    for(let x=0;x<block_list.length;x++){
        let line=[]
        for(let y=0;y<block_list[x].length;y++){
            line.push(block_list[x][y].name)
        }
        new_block_list.push(line)
    }

    return new_block_list
}

function reload_path(){

    class basic_block{
        constructor(){
            this.type="block"

            this.hand_size=.6
            this.collision_box=true

            this.save_traits=["main_hit_box_size","hit_box_index"]



        }

    }

    class blank extends basic_block{
        constructor(){
            super()

            this.name="blank"
            this.hiden_in_accended=true


            if(!is_server){
                this.image=blank_image
            }


        }

    }

    class dirt extends basic_block{
        constructor(){
            
            


            super()
            this.category="nature"

            this.name="dirt"
            this.display_name="Dirt"

            this.destroy_time=2
            if(!is_server){
                this.image=dirt_image
            }
            




        }

    }

    // dirt = {
    //     "name":"dirt",
    //     "destroy_time":2,
    //     "image":dirt_image
    // }





    // t_pre=class t_pre{
    //     constructor(){
    //         this.name=3
    //     }
    // }

    // class t{
    //     constructor(){
    //         this.name=new t_pre()
    //     }
    // }


    // t_2=new t()


    // y={
    //     "y_test":t_2.name
    // }

    // t_2.name="HJNEFNEFJ"

    // alert(y.y_test.name.name)

















    class missing_block extends basic_block{
        constructor(){
            super()

            this.name="missing_block"
            this.display_name="Missing Block"

            this.destroy_time=0

            if(!is_server){
                this.image=missing_block_image
            }
        }

    }

    class knowledge_tablet extends basic_block{
        constructor(){
            super()

            this.transparent=true

            this.hit_box=[2,2]

            this.use_after_duration=1000
            this.on_used=function(){

                // for(let mushroom in mushrooms){
                    // if(mushrooms[mushroom].effect=="poison"){
                    player.add_knowledge({"name":all_mushrooms_colors[0],"text":all_mushrooms_effects[0].knowledge})
                    player.add_knowledge({"name":all_mushrooms_colors[1],"text":all_mushrooms_effects[1].knowledge})
                    player.add_knowledge({"name":all_mushrooms_colors[2],"text":all_mushrooms_effects[2].knowledge})


                    // window[all_mushrooms_effects[0].effect+"_mushroom"]

                    for(let mushroom_index=0;mushroom_index<all_mushrooms_effects.length;mushroom_index++){
                        let mushroom=all_mushrooms_effects[mushroom_index]
                    
                        if(mushroom.effect=="poison"){
                            chat.push({
                                "text":"Knowledge: "+get_block(all_mushrooms_colors[mushroom_index]).display_name+"s are poisonous.",
                                "end_time":engin.time_in_loop+5000,"color":"219, 209, 7"
                            })                              
                        }
                        if(mushroom.effect=="regeneration"){
                            chat.push({
                                "text":"Knowledge: "+get_block(all_mushrooms_colors[mushroom_index]).display_name+"s heal you when eaten.",
                                "end_time":engin.time_in_loop+5000,"color":"219, 209, 7"
                            })                                
                        }

                        if(mushroom.effect=="saturation"){
                            chat.push({
                                "text":"Knowledge: "+get_block(all_mushrooms_colors[mushroom_index]).display_name+"s are safe to eat.",
                                "end_time":engin.time_in_loop+5000,"color":"219, 209, 7"
                            })                               
                        }                    
                    
                        
                    }




                

                  

                    
                // }

            }


            this.name="knowledge_tablet"
            this.display_name="Knowledge Tablet"

            this.destroy_time=5

            if(!is_server){
                this.image=knowledge_tablet_image
            }
        }

    }





    class air extends basic_block{
        constructor(){
            super()

            this.name="air"
            this.hiden_in_accended=true
            this.kills_grass=false

            this.collision_box=false


            

            if(!is_server){
                this.image=air_image
            }
        }

    }


    class grass extends basic_block{
        constructor(){
            super()

            this.category="nature"
            this.name="grass"
            this.display_name="Grass"

            this.destroy_time=2

            if(!is_server){
                this.image=grass_image
            }

            this.random_tick={
                "event":function(x,y){
              
                    if(typeof block_list[x][y-1].kills_grass=="undefined" || block_list[x][y-1].kills_grass){
                        
                        change_block(x,y,"dirt")
                        // console.log("EVENT DO THOIING")
                    }
                    else{
                        if(block_is(x-1,y,"dirt") && block_is(x-1,y-1,"air")){
                            
                            change_block(x-1,y,"grass")
                        // console.log("EVENT DO THOIING")

                    

                        }
                        if(block_is(x+1,y,"dirt")  && block_is(x+1,y-1,"air")){
                            change_block(x+1,y,"grass")
                        // console.log("EVENT DO THOIING")

                        }
                    }



                    
                },
                "loop":true,
                "time":function(){
                    return (10000*Math.random())+14000
                }
            }

        }

    }

    class stone_brick_pedestal extends basic_block{
        constructor(){
            super()

            this.category="nature"
            this.name="stone_brick_pedestal"
            this.display_name="Stone Brick Pedestal"

            this.hit_box=[2,1]
            this.transparent=true

            this.kills_grass=false

            this.destroy_time=3

            if(!is_server){
                this.image=stone_brick_pedestal_image
            }

            // this.random_tick={
            //     "event":function(x,y){
              
            //         if(typeof block_list[x][y-1].kills_grass=="undefined" || block_list[x][y-1].kills_grass){
                        
            //             change_block(x,y,"dirt")
            //             // console.log("EVENT DO THOIING")
            //         }
            //         else{
            //             if(block_is(x-1,y,"dirt") && block_is(x-1,y-1,"air")){
                            
            //                 change_block(x-1,y,"grass")
            //             // console.log("EVENT DO THOIING")

                    

            //             }
            //             if(block_is(x+1,y,"dirt")  && block_is(x+1,y-1,"air")){
            //                 change_block(x+1,y,"grass")
            //             // console.log("EVENT DO THOIING")

            //             }
            //         }



                    
            //     },
            //     "loop":true,
            //     "time":function(){
            //         return (10000*Math.random())+14000
            //     }
            // }

        }

    }

    

    class stone_brick extends basic_block{
        constructor(){
            super()

            this.display_name="Stone Brick"

            this.name="stone_brick"
            // this.destroy_time=10

            this.destroy_time=10


            if(!is_server){
                this.image=stone_brick_image
            }
        }

    }

    class magnifying_glass{
        constructor(){
            

            this.name="magnifying_glass"
            this.destroy_time=0
            this.hand_size=1

            if(!is_server){
                this.image=magnifying_glass_image
            }
            this.hiden_in_accended=true

        }

    }



    // magnifying_glass_image

  

    class cracked_block extends basic_block{
        constructor(){
            super()

            this.name="cracked_block"
            this.hiden_in_accended=true


            if(!is_server){
                this.image=cracked_block_image
            }
        }

    }




    class stone extends basic_block{
        constructor(){
            super()

            // nature
            this.category="earth"

            this.name="stone"
            this.display_name="Stone"

            // this.destroy_time=8

            this.destroy_time=3


            if(!is_server){
                this.image=stone_image
            }
    
          
    
    
    
        }
    
    }


    class blue_mushroom extends basic_block{
        constructor(){
            super()

            // nature
            this.category="nature"

            this.on_used=function(){
                blue_mushroom_function()
            }
            
            this.has_knowledge=true


            this.decrease_after_use=1
            this.use_after_duration=1200

            this.transparent=true
            this.kills_grass=false



            this.collision_box=false

            this.name="blue_mushroom"
            this.display_name="Blue Mushroom"

            // this.destroy_time=8

            this.destroy_time=0


            if(!is_server){
                this.image=blue_mushroom_image
            }
    
          
    
    
    
        }
    
    }

    class red_mushroom extends basic_block{
        constructor(){
            super()

            // nature
            this.category="nature"

            this.has_knowledge=true

            this.collision_box=false
            

            this.transparent=true
            this.kills_grass=false
            
            this.decrease_after_use=1
            this.use_after_duration=1200
            this.on_used=function(){
                red_mushroom_function()
            }


            this.name="red_mushroom"
            this.display_name="Red Mushroom"

            // this.destroy_time=8

            this.destroy_time=0


            if(!is_server){
                this.image=red_mushroom_image
            }
    
          
    
    
    
        }
    
    }

    
    class green_mushroom extends basic_block{
        constructor(){
            super()

            // nature
            this.category="nature"
            this.collision_box=false


            this.has_knowledge=true




            this.decrease_after_use=1
            this.use_after_duration=1200
            this.on_used=function(){
                green_mushroom_function()
            }




            this.transparent=true

            this.kills_grass=false
            this.name="green_mushroom"
            this.display_name="Green Mushroom"

            // this.destroy_time=8

            this.destroy_time=0


            if(!is_server){
                this.image=green_mushroom_image
            }
    
          
    
    
    
        }
    
    }
    
 


    
    
    blocks={"dirt":dirt,"stone":stone,"air":air,"grass":grass,"stone_brick":stone_brick,"cracked_block":cracked_block,"missing_block":missing_block,"blank":blank ,"magnifying_glass":magnifying_glass,"blue_mushroom":blue_mushroom,"green_mushroom":green_mushroom,"red_mushroom":red_mushroom,"knowledge_tablet":knowledge_tablet,"stone_brick_pedestal":stone_brick_pedestal }
}

reload_path()

if(is_server){
    module.exports={get_block,reload_path,change_block,block_is}
}
