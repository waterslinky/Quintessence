//V2.7

if(is_server){
    var {blank_world,generate_elevation_list,convert_names_to_blcoks,convert_blcoks__to_names,get_block,reload_path,noise} = require("./world_parts")
}



let old_temple=[[{"name":"air"},{"name":"air"},{"name":"stone_brick"},{"name":"stone_brick"},{"name":"stone_brick"},{"name":"stone_brick"},{"name":"stone_brick"},{"name":"air"},{"name":"air"},{"name":"stone_brick"}],[{"name":"air"},{"name":"stone_brick"},{"name":"stone_brick"},{"name":"air"},{"name":"air"},{"name":"air"},{"name":"air"},{"name":"air"},{"name":"air"},{"name":"stone_brick"}],[{"name":"stone_brick"},{"name":"stone_brick"},{"name":"air"},{"name":"air"},{"name":"air"},{"name":"air"},{"name":"air"},{"name":"air"},{"name":"air"},{"name":"stone_brick"}],[{"name":"stone_brick"},{"name":"stone_brick"},{"name":"air"},{"name":"air"},{"name":"air"},{"name":"air"},{"name":"knowledge_tablet","data":{"main_hit_box_size":[2,2],"hit_box_index":[0,0]}},{"name":"knowledge_tablet","data":{"main_hit_box_size":[2,2],"hit_box_index":[0,1]}},{"name":"stone_brick_pedestal","data":{"main_hit_box_size":[2,1],"hit_box_index":[0,0]}},{"name":"stone_brick"}],[{"name":"stone_brick"},{"name":"stone_brick"},{"name":"air"},{"name":"air"},{"name":"air"},{"name":"air"},{"name":"knowledge_tablet","data":{"main_hit_box_size":[2,2],"hit_box_index":[1,0]}},{"name":"knowledge_tablet","data":{"main_hit_box_size":[2,2],"hit_box_index":[1,1]}},{"name":"stone_brick_pedestal","data":{"main_hit_box_size":[2,1],"hit_box_index":[1,0]}},{"name":"stone_brick"}],[{"name":"stone_brick"},{"name":"stone_brick"},{"name":"air"},{"name":"air"},{"name":"air"},{"name":"air"},{"name":"air"},{"name":"air"},{"name":"air"},{"name":"stone_brick"}],[{"name":"air"},{"name":"stone_brick"},{"name":"stone_brick"},{"name":"air"},{"name":"air"},{"name":"air"},{"name":"air"},{"name":"air"},{"name":"air"},{"name":"stone_brick"}],[{"name":"air"},{"name":"air"},{"name":"stone_brick"},{"name":"stone_brick"},{"name":"stone_brick"},{"name":"stone_brick"},{"name":"stone_brick"},{"name":"air"},{"name":"air"},{"name":"stone_brick"}]]

red=0
green=0
blue=0

test_map=[]

function over_world(noise_settings){
    let block_list=blank_world()

    let elevation_list=generate_elevation_list({
        "seed":seed,
        "oct":3
    })





    spawn_structures_map=[]
    for(let x=0;x<world_size[0];x++){
        
        let line=[]
        for(let y=0;y<world_size[1];y++){
            
            let spawn_structures=line.push(noise(x*3,y*3,.5,{"seed":seed,"oct":1}))
        }

        spawn_structures_map.push(line)
    }



    for(let x=0;x<world_size[0];x++){
        
        for(let y=0;y<world_size[1];y++){
            if(y==elevation_list[x]){
                block_list[x][y]=get_block("grass")

            }
            if(y==elevation_list[x]+1){
                block_list[x][y]=get_block("dirt")

            }
            if(y==elevation_list[x]+2){
                block_list[x][y]=get_block("dirt")

            }
        

            if(y>=elevation_list[x]){
            
                

        
                if(y>elevation_list[x]){
                    if(block_list[x][y].name=="air"){
                        if(noise(x*8,y*8,.5,noise_settings)>0.6){
                        block_list[x][y]=(get_block("air"))
                        }
                        else{
                
                            block_list[x][y]=(get_block("stone"))
                        }
                    }
                    
                }
            
            }



            let spawn_mushroom=noise(x*150,700,1,{"seed":seed,"oct":20})>.5
       

                if(spawn_mushroom){
                    let mushroom_map=noise(x*5,500,.5,{"seed":seed,"oct":1})


                    if(mushroom_map>.69 && mushroom_map<.8 && block_list[x][y].name=="grass"){

                        // if(mushroom_map>.7 && mushroom_map<=.73174399999999955){
                            red++
                            block_list[x][y-1]=get_block("red_mushroom")

                        // }
                   

                        // if(mushroom_map>.73174399999999955 && mushroom_map<.743314520063999506493956914709997363388538360595703125000000001){
                        //     green++
                        //     block_list[x][y-1]=get_block("green_mushroom")

                        // }

                        // if(mushroom_map>.743314520063999506493956914709997363388538360595703125000000001 && mushroom_map<.8){
                        //     blue++
                        //     block_list[x][y-1]=get_block("blue_mushroom")
                        // }

                        // green++

                        // average++
                        
                        // test_map.push(mushroom_map)
                        // average_list+=mushroom_map
                        
                        // red++
                    }



                    let mushroom_map_2=noise(x*5,500,.5,{"seed":seed*2,"oct":1})


                    if(mushroom_map_2>.69 && mushroom_map_2<.8 && block_list[x][y].name=="grass"){

                        // if(mushroom_map>.7 && mushroom_map<=.73174399999999955){
                            blue++
                            block_list[x][y-1]=get_block("blue_mushroom")

                        // }
                   

                        // if(mushroom_map>.73174399999999955 && mushroom_map<.743314520063999506493956914709997363388538360595703125000000001){
                        //     green++
                        //     block_list[x][y-1]=get_block("green_mushroom")

                        // }

                        // if(mushroom_map>.743314520063999506493956914709997363388538360595703125000000001 && mushroom_map<.8){
                        //     blue++
                        //     block_list[x][y-1]=get_block("blue_mushroom")
                        // }

                        // green++

                        // average++
                        
                        // test_map.push(mushroom_map)
                        // average_list+=mushroom_map
                        
                        // red++
                    }


                    let mushroom_map_3=noise(x*5,500,.5,{"seed":seed*3,"oct":1})


                    if(mushroom_map_3>.69 && mushroom_map_3<.8 && block_list[x][y].name=="grass"){

                        // if(mushroom_map>.7 && mushroom_map<=.73174399999999955){
                            green++
                            block_list[x][y-1]=get_block("green_mushroom")

                        // }
                   

                        // if(mushroom_map>.73174399999999955 && mushroom_map<.743314520063999506493956914709997363388538360595703125000000001){
                        //     green++
                        //     block_list[x][y-1]=get_block("green_mushroom")

                        // }

                        // if(mushroom_map>.743314520063999506493956914709997363388538360595703125000000001 && mushroom_map<.8){
                        //     blue++
                        //     block_list[x][y-1]=get_block("blue_mushroom")
                        // }

                        // green++

                        // average++
                        
                        // test_map.push(mushroom_map)
                        // average_list+=mushroom_map
                        
                        // red++
                    }

                    // let mushroom_map_2=noise(x*5,500,.5,{"seed":seed*2,"oct":1})


                    // if(mushroom_map_2>.7 && mushroom_map_2<.8 && block_list[x][y].name=="grass"){
                    //     // average++
                        
                    //     // average_list+=mushroom_map
                    //     block_list[x][y-1]=get_block("green_mushroom")
                    //     // red++
                    // }

                    // let mushroom_map_3=noise(x*5,500,.5,{"seed":seed*3,"oct":1})


                    // if(mushroom_map_3>.7 && mushroom_map_3<.8 && block_list[x][y].name=="grass"){
                    //     // average++
                        
                    //     // average_list+=mushroom_map
                    //     block_list[x][y-1]=get_block("blue_mushroom")
                    //     blue++
                    // }

                    

                    // let num2=noise(x*10,y*10,.5,{"seed":seed*2,"oct":8})
                    // if(num2>.7 && block_list[x][y].name=="grass"){
                    //     block_list[x][y-1]=get_block("green_mushroom")
                    //     green++

                    // }

                    // let num3=noise(x*10,y*10,.5,{"seed":seed*3,"oct":8})
                    // if(num3>.7 && block_list[x][y].name=="grass" ){
                    //     blue++

                    //     block_list[x][y-1]=get_block("blue_mushroom")
                    // }                    
                }
             
                
          

                



                    if(y==world_size-1){
                block_list[x][y]=get_block("stone")

            }




            









            
        }
        

    }






    for(let x=0;x<world_size[0];x++){
        
        for(let y=0;y<world_size[1];y++){
            if(y>elevation_list[x]+10){

                if(spawn_structures_map[x][y]<.19999){
                    // console.log("test MISSING")         
                    

                    if(typeof spawn_structures_map[x-1]!="undefined" && typeof spawn_structures_map[x+1]!="undefined" && spawn_structures_map[x][y]<=spawn_structures_map[x-1][y] && spawn_structures_map[x][y]<=spawn_structures_map[x+1][y]){
                        if(typeof spawn_structures_map[x][y-1]!="undefined"  && typeof spawn_structures_map[x][y+1]!="undefined" && spawn_structures_map[x][y]<=spawn_structures_map[x][y-1] && spawn_structures_map[x][y]<=spawn_structures_map[x][y+1]){

                            if(spawn_structures_map[x][y]<=spawn_structures_map[x-1][y-1] && spawn_structures_map[x][y]<=spawn_structures_map[x-1][y+1]){
                                if(spawn_structures_map[x][y]<=spawn_structures_map[x+1][y-1] && spawn_structures_map[x][y]<=spawn_structures_map[x+1][y+1]){











                                    let same=true
                                    if(spawn_structures_map[x][y]==spawn_structures_map[x-1][y]){
                                        same=false
                                        // console.log("save1")
                                    }
                                    if(spawn_structures_map[x][y]==spawn_structures_map[x][y-1]){
                                        same=false
                                        // console.log("save2")
                    
                                          
                                    }                    



                
                










                                    if(same){
                                        load_structure(x-3,y-7,old_temple,block_list)
                                        // block_list[x][y]=get_block("missing_block")
                                        
                                        // console.log("Spawn structure.")                                                
                                    }
                                    else{
                                        // console.log("Tryed to spawn structure.")     
                                        // block_list[x][y]=get_block("grass")


                                    }
                                   


                                    
                                    
                                                        
                                }
                            }
                        }
                    }
                    


                    

                }
            }
        }
    }









    return block_list
}



if(is_server){
    module.exports={over_world}
}

