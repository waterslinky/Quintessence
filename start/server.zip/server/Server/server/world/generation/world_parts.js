//V2.7

if(is_server){
    var {get_block,reload_path} = require("../../block")
    var {noise} = require("../../../../common/noise")

}

function blank_world(){
    let block_list=[]

    for(let x=0;x<world_size[0];x++){
        let line=[]
        for(let y=0;y<world_size[1];y++){

            line.push(get_block("air"))

        }
        block_list.push(line)

    }

    return block_list
}


function generate_elevation_list(noise_settings){

    
    let elevation_list=[]
    for(let x=0;x<world_size[0];x++){
        elevation_list.push(parseInt((noise(200,x*3,1,noise_settings)*10)+20))
        // elevation_list.push(20)

    }
    return elevation_list
    
}





function export_world(all_blocks=block_list){
    let new_block_list=[]
    for(let x=0;x<all_blocks.length;x++){
        let line=[]
        for(let y=0;y<all_blocks[0].length;y++){
          

            let block_data={}
            let has_keys=false

            all_blocks[x][y].save_traits.forEach(trait => {
                if(all_blocks[x][y][trait]!=undefined){
                    block_data[trait]=all_blocks[x][y][trait]
                    has_keys=true                    
                }
            });

            // if(block_data.length){
            // console.log(has_keys)
            // }
            
            // block_data={}
            

            line.push({"name":all_blocks[x][y].name,"data":has_keys ? block_data : undefined})

            
        }
        new_block_list.push(line)
            
    }

    return new_block_list
}

function convert_names_to_blocks(block_list_names){
    let block_list=[]
    // alert("T")

    for(let x=0;x<block_list_names.length;x++){
        let line=[]
        for(let y=0;y<block_list_names[0].length;y++){
            let this_block=block_list_names[x][y]

            if(typeof this_block.name!="undefined"){
                block=this_block.name
            

                // console.log(block_list_names[x][y].data)
            }
            
            let add_block=get_block(block)

            // console.log(block.data)
            if(typeof this_block.data!="undefined"){
                // console.log("DATA"+block.data)
                for (element in this_block.data) {
                    add_block[element]=this_block.data[element]
                }
                // this_block.data.forEach(element => {
                //     =element.data
                // });

            }


            

            line.push(add_block)

            // if(typeof block_list_names[x][y].name!="undefined"){
            
            // }
        }
        block_list.push(line)
    
    }

    
    return block_list
}



function save_structure(start_x,start_y,size_x,size_y){
    let structure=[]
    for(let x=start_x;x<start_x+size_x;x++){
        let line=[]

        for(let y=start_y;y<start_y+size_y;y++){
            line.push(block_list[x][y])
        }

        structure.push(line)
    }




    return JSON.stringify(export_world(structure))
    


}

function load_structure(start_x,start_y,structure,all_blocks=block_list){
    // let structure=[]
    for(let x=0;x<structure.length;x++){
        // let line=[]

        for(let y=0;y<structure[0].length;y++){
            // console.log(structure[x][y].data)

            if(x+start_x<world_size[0] && x+start_x>=0){
                if(y+start_y<world_size[1] && y+start_y>=0){
                    // console.log(get_block(structure[x][y].name))
                    all_blocks[x+start_x][y+start_y]=get_block(structure[x][y].name)

                    if(structure[x][y].data!=undefined){

                        for(data in structure[x][y].data){
                            // console.log(data)
                            all_blocks[x+start_x][y+start_y][data]=structure[x][y].data[data]
                        }

                    }                    
                }
            }
            


        }

        // structure.push(line)
    }




    // return JSON.stringify(structure)
    


}

function convert_blocks_to_names(){
    let new_block_list=[]
    for(let x=0;x<block_list.length;x++){
        let line=[]
        for(let y=0;y<block_list[0].length;y++){
            line.push(block_list[x][y].name)
        }
        new_block_list.push(line)
    
    }

    
    return JSON.stringify(new_block_list)
}








if(is_server){
    module.exports={blank_world,generate_elevation_list,convert_names_to_blocks,convert_blocks_to_names,get_block,reload_path,noise}
}
